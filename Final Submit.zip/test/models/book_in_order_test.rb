require "test_helper"

class BookInOrderTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
